setwd("D:\EdenZahala")
library(dplyr)
library(tidyr)

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("RColorBrewer")
BiocManager::install("DESeq2")                     
library("data.table")
library("DESeq2")
library("ggplot2")
library("limma")

countdata <- read.table("miR_combined_data.csv", sep = ",", header=TRUE, row.names = 2)
countdata <- countdata[,-1]   # without the pre-mature miRs
#countdata[1:5,1:5]

#coldata <- read.table("combined_clinical_deseq_HYPO.csv", header= TRUE, sep = ",")
#coldata <- coldata[,-5]

coldata <- read.table("data_without_6_cogdx\\combined_clinical_data_NUCC_no6_SEX_condition_APOE_allRINs.csv", header= TRUE, sep = ",")

coldata <- coldata[(coldata$RINbatch!="2to3" & coldata$RINbatch!="3to4"),]
#coldata <- coldata[(coldata$RINbatch!="4to5" & coldata$RINbatch!="5to6"),]

coldata <- coldata[(coldata$condition!="mid"),]

coldata$BUID <- sapply(coldata$BUID, function(x) paste0("X",x))



#write.csv(as.data.frame(coldata), "combined_clinical_deseq_HYPO_6plusRINs.csv")
#countdata[1,] <- sapply(countdata[1,], function(x) paste0("X",x))
#coldata$SEX <- sapply(coldata$SEX, function(x) paste0("S",x))

coldata$miRNA_batch <- sapply(coldata$miRNA_batch, function(x) paste0("M",x))


#### taking the matching samples with batch rin >= 6 ##########

n <- colnames(countdata)
idxs <- c()
for (i in 1:ncol(countdata)){
  if (n[i] %in% coldata$BUID)
  {
   idxs <- c(idxs,i)
 }
}

countdata <- countdata[, idxs]
countdata <- as.matrix(countdata)
##################

#write.csv(as.data.frame(countdata), "mirs_mature_SEX_sick_health.csv")

coldata$msex <- as.factor(coldata$msex)
coldata$condition <- as.factor(coldata$condition)
coldata$RINbatch<- as.factor(coldata$RINbatch)
#coldata$brain_region<- as.factor(coldata$brain_region)
coldata$miRNA_batch <- as.factor(coldata$miRNA_batch)

dds <- DESeqDataSetFromMatrix(countData=countdata, colData=coldata, design=~miRNA_batch + msex + RINbatch + condition)
dds

mean(rowMeans(counts(dds))) #1442.671
keep <- rowMeans(counts(dds)) >= 54
dds <- dds[keep,]

dds$msex <- relevel(dds$msex, ref = "male")

dds <- DESeq(dds)

resultsNames(dds)
plotDispEsts(dds)


#countsnorm = counts(dds, normalize=T)
#write.csv(as.data.frame(countsnorm), "countsnorm.csv")


#res <- results(dds, alpha=0.05) #setting alpha to be 0.05
res <- results(dds)
# res<- results(dds, contrast=c("SEX","S1","S2"), alpha=0.05) #setting alpha to be 0.05

res <- results(dds, contrast=c("msex","male","female"))

summary(res) #summarize results

resOrdered <- res[order(res$padj),] # order results table by the smallest p value
resOrdered
resOrdered[1:10, ] #present 10 most significant genes
sum(res$padj < 0.05, na.rm=TRUE) #How many genes were less than 0.05 (41)
table(is.na(res$padj))  #0 NA

#nsub=nrow(dds)
#vsd <- vst(dds, blind=FALSE)

rld <-rlogTransformation(dds)

mat <- assay(rld)
mat <- limma::removeBatchEffect(mat, rld$RIN) #correction of just sepsis looked the same as no correction at all!
mat <- limma::removeBatchEffect(mat, rld$miRNA_batch)
assay(rld) <- mat 

#sampleDists <- dist(t(assay(vsd)))

sampleDists <- dist(t(assay(rld)))

library("RColorBrewer")
library("pheatmap")
sampleDistMatrix <- as.matrix(sampleDists)
#rownames(sampleDistMatrix) <- paste(vsd$Diagnosis)
rownames(sampleDistMatrix) <- paste(rld$Diagnosis)

colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
#pheatmap(sampleDistMatrix, clustering_distance_rows=sampleDists,clustering_distance_cols=sampleDists,
#         col=colors)
plotPCA(rld, intgroup="msex")
plotPCA(rld, intgroup="condition")
plotPCA(rld, intgroup="APOE")
plotPCA(rld, intgroup="cts_mmse30_lv")
plotPCA(rld, intgroup="RIN")
plotPCA(rld, intgroup="miRNA_batch")
plotPCA(rld, intgroup=c("msex","condition"))

plotCounts(dds, gene="hsa-miR-30e-5p", intgroup="condition")
plotCounts(dds, gene="hsa-miR-30e-3p", intgroup="condition")
plotCounts(dds, gene="hsa-miR-125b-2-3p", intgroup="condition")
plotCounts(dds, gene="hsa-miR-382-3p", intgroup="condition")
plotCounts(dds, gene="hsa-let-7f-5p", intgroup="condition")


BiocManager::install("calibrate")
library("calibrate")

library(RColorBrewer)
(mycols <- brewer.pal(8, "Dark2"))
rld_pca <- function (rld, intgroup = "condition", ntop = 500, colors=NULL, legendpos="bottomleft", main="PCA Biplot", textcx=1, ...) {
require(genefilter)
require(calibrate)
require(RColorBrewer)
rv = rowVars(assay(rld))
select = order(rv, decreasing = TRUE)[seq_len(min(ntop, length(rv)))]
pca = prcomp(t(assay(rld)[select, ]))
fac = factor(apply(as.data.frame(colData(rld)[, intgroup, drop = FALSE]), 1, paste, collapse = " : "))
if (is.null(colors)) {
  if (nlevels(fac) >= 3) {
    colors = brewer.pal(nlevels(fac), "Paired")
  }   else {
    colors = c("black", "red")
  }
}
pc1var <- round(summary(pca)$importance[2,1]*100, digits=1)
pc2var <- round(summary(pca)$importance[2,2]*100, digits=1)
pc1lab <- paste0("PC1 (",as.character(pc1var),"%)")
pc2lab <- paste0("PC1 (",as.character(pc2var),"%)")
plot(PC2~PC1, data=as.data.frame(pca$x), bg=colors[fac], pch=21, xlab=pc1lab, ylab=pc2lab, main=main, ...)
with(as.data.frame(pca$x), textxy(PC1, PC2, labs=rownames(as.data.frame(pca$x)), cex=textcx))
legend(legendpos, legend=levels(fac), col=colors, pch=20)
#     rldyplot(PC2 ~ PC1, groups = fac, data = as.data.frame(pca$rld),
#            pch = 16, cerld = 2, aspect = "iso", col = colours, main = draw.key(key = list(rect = list(col = colours),
#                                                                                         terldt = list(levels(fac)), rep = FALSE)))
}
png("qc-pca.png", 1000, 1000, pointsize=20)
rld_pca(rld, colors=mycols, intgroup="condition", xlim=c(-75, 50))
dev.off()
