setwd("D:\EdenZahala\files")
library(dplyr)
library(tidyr)
BiocManager::install("data.table")
library("data.table")

BiocManager::install("DESeq2")
library("DESeq2")

countdata <- read.table("miR_noDup_mature_no6.csv", header= TRUE, sep = ",", row.names = 1)
countdata <- as.matrix(countdata)
#countdata[1:5,1:5]

coldata <- read.table("sick_healtyh_table_no6.csv", header= TRUE, sep = ",")

coldata$BUID <- sapply(coldata$BUID,function(x) paste0("X",x))

