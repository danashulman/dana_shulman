setwd("D:\EdenZahala")
library(dplyr)
library(tidyr)

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("RColorBrewer")
BiocManager::install("DESeq2")                     
library("data.table")
library("DESeq2")
library("ggplot2")
library("limma")

countdata <- read.table("miR_combined_data.csv", sep = ",", header=TRUE, row.names = 2)
countdata <- countdata[,-1]   # without the pre-mature miRs
#countdata[1:5,1:5]

#coldata <- read.table("combined_clinical_deseq_HYPO.csv", header= TRUE, sep = ",")
#coldata <- coldata[,-5]

coldata <- read.table("data_without_6_cogdx\\combined_clinical_data_no6_SEX_sick_healthy.csv", header= TRUE, sep = ",")

coldata <- coldata[(coldata$RINbatch!="2to3" & coldata$RINbatch!="3to4"),]

coldata$BUID <- sapply(coldata$BUID, function(x) paste0("X",x))


#coldata <- coldata[(coldata$RINbatch!="4to5" & coldata$RINbatch!="5to6"),]
#write.csv(as.data.frame(coldata), "combined_clinical_deseq_HYPO_6plusRINs.csv")
#countdata[1,] <- sapply(countdata[1,], function(x) paste0("X",x))
#coldata$SEX <- sapply(coldata$SEX, function(x) paste0("S",x))

coldata$miRNA_batch <- sapply(coldata$miRNA_batch, function(x) paste0("M",x))


#### taking the matching samples with batch rin >= 6 ##########

n <- colnames(countdata)
idxs <- c()
for (i in 1:ncol(countdata)){
  if (n[i] %in% coldata$BUID)
  {
   idxs <- c(idxs,i)
 }
}

countdata <- countdata[, idxs]
countdata <- as.matrix(countdata)
##################

write.csv(as.data.frame(countdata), "mirs_mature_SEX_sick_health.csv")

coldata$msex <- as.factor(coldata$msex)
coldata$condition <- as.factor(coldata$condition)
coldata$RINbatch<- as.factor(coldata$RINbatch)
coldata$brain_region<- as.factor(coldata$brain_region)
coldata$miRNA_batch <- as.factor(coldata$miRNA_batch)

dds <- DESeqDataSetFromMatrix(countData=countdata, colData=coldata, design=~miRNA_batch + msex + RINbatch + condition +brain_region)
dds

#mean(rowMeans(counts(dds))) #1442.671
#keep <- rowMeans(counts(dds)) >= 5
#dds <- dds[keep,]

dds$condition <- relevel(dds$condition, ref = "healthy")

dds <- DESeq(dds)

resultsNames(dds)
plotDispEsts(dds)


#countsnorm = counts(dds, normalize=T)
#write.csv(as.data.frame(countsnorm), "countsnorm.csv")


#res <- results(dds, alpha=0.05) #setting alpha to be 0.05
res <- results(dds)
# res<- results(dds, contrast=c("SEX","S1","S2"), alpha=0.05) #setting alpha to be 0.05
res <- results(dds, contrast=c("condition","sick","healthy"))

summary(res) #summarize results

resOrdered <- res[order(res$padj),] # order results table by the smallest p value
resOrdered
resOrdered[1:10, ] #present 10 most significant genes
sum(res$padj < 0.05, na.rm=TRUE) #How many genes were less than 0.05 (41)
table(is.na(res$padj))  #0 NA

#nsub=nrow(dds)
#vsd <- vst(dds, blind=FALSE)

rld <-rlogTransformation(dds)
#sampleDists <- dist(t(assay(vsd)))

sampleDists <- dist(t(assay(rld)))

library("RColorBrewer")
library("pheatmap")
sampleDistMatrix <- as.matrix(sampleDists)
#rownames(sampleDistMatrix) <- paste(vsd$Diagnosis)
rownames(sampleDistMatrix) <- paste(rld$Diagnosis)

colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix,
         clustering_distance_rows=sampleDists,
         clustering_distance_cols=sampleDists,
         col=colors)
plotPCA(rld, intgroup="msex")
plotPCA(rld, intgroup="condition")

plotPCA(rld, intgroup="RIN")
plotPCA(rld, intgroup="miRNA_batch")
