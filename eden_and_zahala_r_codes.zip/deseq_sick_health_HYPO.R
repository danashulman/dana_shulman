setwd("D:\EdenZahala\files")
library(dplyr)
library(tidyr)

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("RColorBrewer")
BiocManager::install("DESeq2")                     
alibrary("data.table")
library("DESeq2")
library("ggplot2")
library("limma")

countdata <- read.table("mirs_HYPO_mature_no6_BATCH_RIN.csv", sep = ",", header=TRUE, row.names = 1)
#countdata[1:5,1:5]

#coldata <- coldata[(coldata$RINbatch!="2to3" & coldata$RINbatch!="3to4"),]

coldata <- read.table("combined_clinical_deseq_HYPO.csv", header= TRUE, sep = ",")

coldata <- coldata[, -5]

  
#countdata[1,] <- sapply(countdata[1,], function(x) paste0("X",x))
coldata$BUID <- sapply(coldata$BUID, function(x) paste0("X",x))
coldata$miRNA_batch <- sapply(coldata$miRNA_batch, function(x) paste0("M",x))
coldata$SEX <- sapply(coldata$SEX, function(x) paste0("S",x))

countdata <- as.matrix(countdata)

#write.csv(as.data.frame(coldata), "combined_clinical_deseq.csv")


coldata$SEX <- as.factor(coldata$SEX)
coldata$condition <- as.factor(coldata$condition)
#coldata$brain_region <- as.factor(coldata$brain_region)  - no need because we seperated the data into HYPO and NUCC
coldata$RINbatch<- as.factor(coldata$RINbatch)
coldata$miRNA_batch <- as.factor(coldata$miRNA_batch)

#dds <- DESeqDataSetFromMatrix(countData=countdata, colData=coldata, design=~miRNA_batch + brain_region + SEX + RINbatch + condition)
dds <- DESeqDataSetFromMatrix(countData=countdata, colData=coldata, design=~miRNA_batch + SEX + RINbatch + condition)
dds

#mean(rowMeans(counts(dds))) #1442.671
#keep <- rowMeans(counts(dds)) >= 5
#dds <- dds[keep,]

dds$condition <- relevel(dds$condition, ref = "healthy")

dds <- DESeq(dds)

resultsNames(dds)
plotDispEsts(dds)


#countsnorm = counts(dds, normalize=T)
#write.csv(as.data.frame(countsnorm), "countsnorm.csv")


#res <- results(dds, alpha=0.05) #setting alpha to be 0.05
res <- results(dds)
# res<- results(dds, contrast=c("SEX","S1","S2"), alpha=0.05) #setting alpha to be 0.05
res <- results(dds, contrast=c("condition","sick","healthy"))
summary(res) #summarize results

resOrdered <- res[order(res$padj),] # order results table by the smallest p value
resOrdered
resOrdered[1:10, ] #present 10 most significant genes
sum(res$padj < 0.05, na.rm=TRUE) #How many genes were less than 0.05 (41)
table(is.na(res$padj))  #0 NA

nsub=nrow(dds)
vsd <- vst(dds, blind=FALSE)

sampleDists <- dist(t(assay(vsd)))
library("RColorBrewer")
library("pheatmap")
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(vsd$Diagnosis)
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix,
         clustering_distance_rows=sampleDists,
         clustering_distance_cols=sampleDists,
         col=colors)

plotPCA(vsd, intgroup="Batch")
plotPCA(vsd, intgroup="Diagnosis")
plotPCA(vsd, intgroup="RIN")
plotPCA(vsd, intgroup="Sepsis")
