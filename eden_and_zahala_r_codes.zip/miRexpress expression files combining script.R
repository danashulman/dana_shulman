setwd("D:\EdenZahala\files")
library(dplyr)
library(tidyr)

BiocManager::install("data.table")
library("data.table")
file_list <- list.files(pattern = "expression.fq")
txt_files_df <- lapply(file_list, function(x) {fread(file = x, select = c(1,2), data.table = FALSE,header = F,sep = "\t")})
combined_df <- Reduce(function(x,y) {merge(x,y, by = "V1", all=TRUE)}, txt_files_df)
rownames(combined_df) <- combined_df$V1
combined_df1 <- combined_df[,-1]
colnames(combined_df1) <- gsub("_trimmed.expression.fq", "", file_list)
combined_df1[is.na(combined_df1)] <- 0
write.csv(combined_df1, "miR_combined_data.csv")





