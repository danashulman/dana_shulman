setwd("/SeagateDrive/EdenZahala/files/")
library(plyr)
library(dplyr)
library(tidyr)
data <- read.csv(file ="combined_clinical_data.csv")

healthy <- data[data$cogdx == 1 , ]
sick <- data[data$cogdx > 1 & data$cogdx < 6,]
#cog_vec <- data["cogdx"]
#healthy <- count(cog_vec, vars = 1, wt_var = 'cogdx')

