###Deferential expression (DE) analysis with DESeq2

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("limma")

library("DESeq2")
library("EnhancedVolcano")
library("ggplot2")
library("limma")
#dir <- "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/RIN_correction" # choose working folder
dir <- "G:/computer_backup_07.11.19/R/mRNA/corrected_DE/RIN+sepsis correction"
setwd(dir)
colData <- read.csv("malePdata030919_shortVersion3.csv",header = T, sep = ',') #reads in patints data file (Patients_Traits) 

#create a data set from HTSeq files
directory <- "G:\\computer_backup_07.11.19\\R\\mRNA\\final final\\files to send with\\HTseq_male" # choose HTSeq_files folder
sampleFiles <- grep('.HTseq.stats',list.files(directory),value=TRUE) 

#create new data frame combining HTSeq files and traits factors
sampleTable <- data.frame(sampleName = colData$sample.name, fileName = sampleFiles, Diagnosis = as.factor(colData$diagnosis), 
                          Batch = as.factor(colData$batch), RIN = as.factor(colData$RIN_groups), BraakLB = as.factor(colData$braaklb),
                          Age = as.factor(colData$age), Braak = as.factor(colData$braak), PMDblood = as.factor(colData$pmd.blood),
                          ApoE = as.factor(colData$apoe), Amyloid = as.factor(colData$amyloid),Duration = as.factor(colData$pd.duration..y.),
                          Sepsis = as.factor(colData$sepsis))

# Balance design for clot and batch effects
ddsHTSeq <- DESeqDataSetFromHTSeqCount(sampleTable = sampleTable, directory = directory,
                                         design = ~Batch + RIN + Sepsis + Diagnosis) 
ddsHTSeq

#pre filtering of rows with less than 1000 reads average
mean(rowSums(counts(ddsHTSeq))) #14168.89
mean(rowMeans(counts(ddsHTSeq))) #372.8654
#keep <- rowSums(counts(ddsHTSeq)) >= 40 #the role of tumb is no less than 20, I've put approximetly the number of samples
keep <- rowMeans(counts(ddsHTSeq)) >= 30 #started at 10, continues until left top group of outliers was out +
                                        #low counts were around 15% or lower + filterNumRej was less than 0.1
                                        #and pheatmap show something interesting
ddsHTSeq <- ddsHTSeq[keep,]

#specifying the reference level of the Diagnosiss (which one is control)
ddsHTSeq$Diagnosis <- relevel(ddsHTSeq$Diagnosis, ref = "NDC")

#preforming DE analysis
ddsHTSeq <- DESeq(ddsHTSeq)

resultsNames(ddsHTSeq) # check order of the coefficient, sanity check

#Exporting gene count per sample to CSV file
countsnorm = counts(ddsHTSeq, normalize=T)
#write.csv(as.data.frame(countsnorm), "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/Mcountsnorm.csv")
write.csv(as.data.frame(countsnorm), "G:/computer_backup_07.11.19/R/mRNA/corrected_DE/RIN+sepsis correction/Mcountsnorm.csv")

#check dispersion to know if data fit Wald test (DESeq2 automatic option)
plotDispEsts(ddsHTSeq) #dispersion plot 

#Cooks distance check
#####
#assays(dds)[["cooks"]] - store the results of the Cook�s distance. those genes will have thier P.adjust marked as NA!
CooksCuts <- assays(ddsHTSeq)[["cooks"]]
max(CooksCuts) #18.26225
min(CooksCuts) #1.066184e-13
mean(CooksCuts) #0.09524111
median(CooksCuts) #0.01964226
#####

#run Sample correlation dendrograms and percent distance heat map 
vsd <- vst(ddsHTSeq, blind=FALSE)

mat <- assay(vsd)
mat <- limma::removeBatchEffect(mat, vsd$RIN) #correction of just sepsis looked the same as no correction at all!
assay(vsd) <- mat                             #decided to correct for RIN & Batch.

mat <- assay(vsd)
mat <- limma::removeBatchEffect(mat, vsd$Batch) 
assay(vsd) <- mat

sampleDists <- dist(t(assay(vsd)))
library("RColorBrewer")
library("pheatmap")
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(vsd$Diagnosis)
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix,
         clustering_distance_rows=sampleDists,
         clustering_distance_cols=sampleDists,
         col=colors)

plotPCA(vsd, intgroup="Batch")
plotPCA(vsd, intgroup="Diagnosis")
plotPCA(vsd, intgroup="RIN")
plotPCA(vsd, intgroup="Sepsis")

##results of contrust #1 - NDNDPD vs NDC
res_NDPDvsNDC <- results(ddsHTSeq, contrast=c("Diagnosis","NDPD","NDC"), alpha=0.05) #setting alpha to be 0.05
summary(res_NDPDvsNDC) #summarize results

resOrdered_NDPDvsNDC <- res_NDPDvsNDC[order(res_NDPDvsNDC$padj),] # order results table by the smallest p value
resOrdered_NDPDvsNDC[1:10, ] #present 10 most significant genes
sum(res_NDPDvsNDC$padj < 0.05, na.rm=TRUE) #How many genes were less than 0.05 (41)
table(is.na(res_NDPDvsNDC$padj))  #0 NA

#plotMA(res_NDPDvsNDC) # show logfold change in comparison to mean of normelized counts
DESeq2::plotMA(res_NDPDvsNDC, ylim=c(-5,5)) #limma package has a plotMA function too, so when it's activated you need to specify

#write.csv(as.data.frame(resOrdered_NDPDvsNDC), "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/Mres_NDPDvsNDC_full.csv")
write.csv(as.data.frame(resOrdered_NDPDvsNDC), "G:/computer_backup_07.11.19/R/mRNA/corrected_DE/RIN+sepsis correction/Mres_NDPDvsNDC_full.csv")
Padj_res_NDPDvsNDC <- as.data.frame(resOrdered_NDPDvsNDC[which(resOrdered_NDPDvsNDC$padj < 0.05), ]) 
#write.csv(as.data.frame(Padj_res_NDPDvsNDC), "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/Mres_NDPDvsNDC_sig.csv")
write.csv(as.data.frame(Padj_res_NDPDvsNDC), "G:/computer_backup_07.11.19/R/mRNA/corrected_DE/RIN+sepsis correction/Mres_NDPDvsNDC_sig.csv")

##results of contrust #2 - PDD vs NDC
res_PDDvsNDC <- results(ddsHTSeq, contrast=c("Diagnosis","PDD","NDC"), alpha=0.05)
res_PDDvsNDC
resOrdered_PDDvsNDC <- res_PDDvsNDC[order(res_PDDvsNDC$padj), ]
summary(res_PDDvsNDC)
sum(res_PDDvsNDC$padj < 0.05, na.rm=TRUE) # 343 significantly DE genes
resOrdered_PDDvsNDC[1:10, ]
table(is.na(res_PDDvsNDC$padj)) #2156  NA

#plotMA(res_PDDvsNDC, ylim=c(-5,5))
DESeq2::plotMA(res_PDDvsNDC, ylim=c(-5,5))
dev.off()

#write.csv(as.data.frame(resOrdered_PDDvsNDC), "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/Mres_PDDvsNDC_full.csv")
write.csv(as.data.frame(resOrdered_PDDvsNDC), "G:/computer_backup_07.11.19/R/mRNA/corrected_DE/RIN+sepsis correction/Mres_PDDvsNDC_full.csv")
Padj_res_PDDvsNDC <- as.data.frame(resOrdered_PDDvsNDC[which(resOrdered_PDDvsNDC$padj < 0.05), ]) 
#write.csv(as.data.frame(Padj_res_PDDvsNDC), "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/Mres_PDDvsNDC_sig.csv")
write.csv(as.data.frame(Padj_res_PDDvsNDC), "G:/computer_backup_07.11.19/R/mRNA/corrected_DE/RIN+sepsis correction/Mres_PDDvsNDC_sig.csv")

######
##results of contrust #3 - PDD vs NDPD
dds <- DESeqDataSetFromHTSeqCount(sampleTable = sampleTable, directory = directory,
                                       design = ~Batch + RIN + Sepsis + Diagnosis) 
dds

#pre filtering of rows with less than 1000 reads average
mean(rowSums(counts(dds))) #14168.89
keep <- rowMeans(counts(dds)) >= 30
dds <- dds[keep,]
#specifying the reference level of the Diagnosiss (which one is control)
dds$Diagnosis <- relevel(dds$Diagnosis, ref = "NDPD")

#preforming DE analysis
dds <- DESeq(dds)

resultsNames(dds) # check order of the coefficient, sanity check
res_PDDvsNDPD <- results(dds, contrast=c("Diagnosis","PDD","NDPD"), alpha=0.05)
resOrdered_PDDvsNDPD <- res_PDDvsNDPD[order(res_PDDvsNDPD$padj), ]
summary(res_PDDvsNDPD)
sum(res_PDDvsNDPD$padj < 0.05, na.rm=TRUE) # 0 significantly DE genes
resOrdered_PDDvsNDPD[1:10, ]

#plotMA(res_PDDvsNDPD, ylim=c(-4.5,4.5))
DESeq2::plotMA(res_PDDvsNDPD, ylim=c(-4.5,4.5)) #limma package has a plotMA function too, so when it's activated you need to specify
dev.off()
######

##Create significantly DE genes data frames for each contrast
#creat new dataframe of padj < 0.05
Padj_res_NDPDvsNDC <- as.data.frame(res_NDPDvsNDC[which(res_NDPDvsNDC$padj < 0.05), ]) 
ddsHTSeq2NDPD <- ddsHTSeq[rownames(Padj_res_NDPDvsNDC)]

Padj_res_PDDvsNDC <- as.data.frame(res_PDDvsNDC[which(res_PDDvsNDC$padj < 0.05), ]) 
ddsHTSeq2PDD <- ddsHTSeq[rownames(Padj_res_PDDvsNDC)]

vsd2 <- varianceStabilizingTransformation(ddsHTSeq2NDPD, blind=FALSE) #preforme trnsformation 
vsd3 <- varianceStabilizingTransformation(ddsHTSeq2PDD, blind=FALSE)
#blance for batch effect for vsd
mat <- assay(vsd2)
mat <- limma::removeBatchEffect(mat, vsd2$Batch)
assay(vsd2) <- mat

mat <- assay(vsd2)
mat <- limma::removeBatchEffect(mat, vsd2$RIN)
assay(vsd2) <- mat

mat <- assay(vsd3)
mat <- limma::removeBatchEffect(mat, vsd3$Batch)
assay(vsd3) <- mat

mat <- assay(vsd3)
mat <- limma::removeBatchEffect(mat, vsd3$RIN)
assay(vsd3) <- mat

#run Sample correlation dendrograms and percent distance heat map 
sampleDists <- dist(t(assay(vsd2)))
library("RColorBrewer")
library("pheatmap")
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(vsd$Diagnosis)
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix,
         clustering_distance_rows=sampleDists,
         clustering_distance_cols=sampleDists,
         col=colors)

sampleDists <- dist(t(assay(vsd3)))
library("RColorBrewer")
library("pheatmap")
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(vsd$Diagnosis)
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix,
         clustering_distance_rows=sampleDists,
         clustering_distance_cols=sampleDists,
         col=colors)

#plot PCA VST
plotPCA(vsd2, intgroup="Batch")
plotPCA(vsd2, intgroup="Diagnosis")
plotPCA(vsd2, intgroup="Age")
plotPCA(vsd2, intgroup="Batch")
plotPCA(vsd2, intgroup="Braak")
plotPCA(vsd2, intgroup="BraakLB")
plotPCA(vsd2, intgroup="Amyloid")
plotPCA(vsd2, intgroup="ApoE")
plotPCA(vsd2, intgroup="PMDblood")
plotPCA(vsd2, intgroup="RIN")
plotPCA(vsd2, intgroup="Duration")
plotPCA(vsd2, intgroup=c("Diagnosis","BraakLB"))

#plot PCA VST
plotPCA(vsd3, intgroup="Batch")
plotPCA(vsd3, intgroup="Diagnosis")
plotPCA(vsd3, intgroup="Age")
plotPCA(vsd3, intgroup="Batch")
plotPCA(vsd3, intgroup="Braak")
plotPCA(vsd3, intgroup="BraakLB")
plotPCA(vsd3, intgroup="Amyloid")
plotPCA(vsd3, intgroup="ApoE")
plotPCA(vsd3, intgroup="PMDblood")
plotPCA(vsd3, intgroup="RIN")
plotPCA(vsd3, intgroup="Duration")
plotPCA(vsd3, intgroup=c("Diagnosis","BraakLB"))

pcaData <- plotPCA(vsd2, intgroup = c("BraakLB", "Diagnosis"), returnData=TRUE)
percentVar <- round(100 * attr(pcaData, "percentVar"))
ggplot(pcaData, aes(PC1, PC2, color = BraakLB, shape = Diagnosis )) +
  geom_point(size=3) +
  xlab(paste0("PC1: ",percentVar[1],"% variance")) +
  ylab(paste0("PC2: ",percentVar[2],"% variance")) + 
  coord_fixed()

pcaData <- plotPCA(vsd3, intgroup = c("BraakLB", "Diagnosis"), returnData=TRUE)
percentVar <- round(100 * attr(pcaData, "percentVar"))
ggplot(pcaData, aes(PC1, PC2, color = BraakLB, shape = Diagnosis )) +
  geom_point(size=3) +
  xlab(paste0("PC1: ",percentVar[1],"% variance")) +
  ylab(paste0("PC2: ",percentVar[2],"% variance")) + 
  coord_fixed()

#find which genes are shared
comb <- rownames(Padj_res_PDDvsNDC)[rownames(Padj_res_PDDvsNDC) %in% rownames(Padj_res_NDPDvsNDC)]
length(comb) #225
Comb <- as.data.frame(Padj_res_NDPDvsNDC[comb, ])
Comb <- Comb[order(Comb$padj), ]
Comb[1:10, ]
#write.csv(as.data.frame(Comb), "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/Mres_comb.csv") #Exporting results to CSV files
write.csv(as.data.frame(Comb), "G:/computer_backup_07.11.19/R/mRNA/corrected_DE/RIN+sepsis correction/Mres_comb.csv")

#find which genes are not shared
Diff_PDD <- rownames(Padj_res_PDDvsNDC)[!(rownames(Padj_res_PDDvsNDC) %in% rownames(Padj_res_NDPDvsNDC))]
length(Diff_PDD) #1102
Diff_PDD <- as.data.frame(Padj_res_PDDvsNDC[Diff_PDD, ])
Diff_PDD <- Diff_PDD[order(Diff_PDD$padj), ]
from <- rep("PDD",length(Diff_PDD$baseMean))
Diff_PDD <- cbind(Diff_PDD, from)
Diff_PDD[1:10, ]

Diff_NDPD <- rownames(Padj_res_NDPDvsNDC)[!(rownames(Padj_res_NDPDvsNDC) %in% rownames(Padj_res_PDDvsNDC))]
length(Diff_NDPD) #73
Diff_NDPD <- as.data.frame(Padj_res_NDPDvsNDC[Diff_NDPD, ])
Diff_NDPD <- Diff_NDPD[order(Diff_NDPD$padj), ]
from <- rep("NDPD",length(Diff_NDPD$baseMean))
Diff_NDPD <- cbind(Diff_NDPD, from)
Diff_NDPD[1:10, ]

Diff <- rbind(Diff_PDD, Diff_NDPD)
#write.csv(as.data.frame(Diff), "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/Mres_diff.csv") #Exporting results to CSV files
write.csv(as.data.frame(Diff), "G:/computer_backup_07.11.19/R/mRNA/corrected_DE/RIN+sepsis correction/Mres_diff.csv")
  
##create count of just significant DE genes
MDiffCounts <- as.data.frame(countsnorm[rownames(Diff), ])
MCombCounts <- as.data.frame(countsnorm[rownames(Comb), ])

sigCounts <- rbind(MCombCounts,MDiffCounts)
dim(sigCounts)
#write.csv(sigCounts, "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/MsigCounts.csv")
write.csv(sigCounts, "G:/computer_backup_07.11.19/R/mRNA/corrected_DE/RIN+sepsis correction/MsigCounts.csv")

##plot volcanos
volc_NDPD <- EnhancedVolcano(res_NDPDvsNDC,lab = rownames(res_NDPDvsNDC),x = 'log2FoldChange',y = 'padj',xlim=c(-4,4),xlab = bquote(~Log[2]~ 'fold change'),
                ylab = bquote(~-Log[10]~adjusted~italic(P)), ylim = c(0,6), pCutoff = 0.05,FCcutoff = 1.0,transcriptLabSize = 3.5,
                colAlpha = 1,legend=c('NS','Log2 FC','Adjusted p-value','Adjusted p-value & Log2 FC'), legendPosition = 'bottom',
                legendLabSize = 9,legendIconSize = 2.0, axisLabSize = 10, titleLabSize = 14, subtitle ="", captionLabSize = 9, 
                title = "a. NDPD vs. NDC")

Volc_PDD <- EnhancedVolcano(res_PDDvsNDC,lab = rownames(res_NDPDvsNDC),x = 'log2FoldChange',y = 'padj',xlim=c(-4,4),xlab = bquote(~Log[2]~ 'fold change'),
                             ylab = bquote(~-Log[10]~adjusted~italic(P)), ylim = c(0,6), pCutoff = 0.05,FCcutoff = 1.0,transcriptLabSize = 3.5,
                             colAlpha = 1,legend=c('NS','Log2 FC','Adjusted p-value','Adjusted p-value & Log2 FC'), legendPosition = 'bottom',
                             legendLabSize = 9,legendIconSize = 2.0, axisLabSize = 10, titleLabSize = 14, subtitle ="", captionLabSize = 9, 
                             title = "b. PDD vs. NDC")

Volc_PD <- EnhancedVolcano(Diff,lab = rownames(Diff),x = 'log2FoldChange',y = 'padj',xlim=c(-4,4),xlab = bquote(~Log[2]~ 'fold change'),
                            ylab = bquote(~-Log[10]~adjusted~italic(P)), ylim = c(0,6), pCutoff = 0.05,FCcutoff = 1.0,transcriptLabSize = 3.5,
                            colAlpha = 1,legend=c('NS','Log2 FC','Adjusted p-value','Adjusted p-value & Log2 FC'), legendPosition = 'bottom',
                            legendLabSize = 9,legendIconSize = 2.0, axisLabSize = 10, titleLabSize = 14, subtitle ="", captionLabSize = 9, 
                            title = "c. Different significantly DE genes between PDD.NDPD and NDC")
library(gridExtra)
library(grid)
#grid.arrange(volc_NDPD, Volc_PDD, Volc_PD, ncol=3)
grid.arrange(volc_NDPD, Volc_PDD, ncol=2)
dev.off()
##variance stabilizing transformations 
rld <- rlog(ddsHTSeq, blind=FALSE)

#blance for batch effect for vsd
mat <- assay(rld)
mat <- limma::removeBatchEffect(mat, rld$Batch)
assay(rld) <- mat

#plot PCA rlog
plotPCA(rld, intgroup=c("Batch"))
plotPCA(rld, intgroup=c("Diagnosis"))

pcaData <- plotPCA(rld, intgroup = c("BraakLB", "Diagnosis"), returnData=TRUE)
percentVar <- round(100 * attr(pcaData, "percentVar"))
ggplot(pcaData, aes(PC1, PC2, color = BraakLB, shape = Diagnosis )) +
  geom_point(size=3) +
  xlab(paste0("PC1: ",percentVar[1],"% variance")) +
  ylab(paste0("PC2: ",percentVar[2],"% variance")) + 
  coord_fixed()

## compare DE genes to cholinergic genes
cholinData <- read.csv("C:/Users/Shani Vaknine/Documents/R/mRNA/final final/files to send with/cholinergic_genes.csv",header = T, sep = ',') #reads in cholinergic_genes.csv

cholin_genes <- cholinData$gene_symbol
length(cholin_genes) #102
inter_cholin_NDPD <- cholin_genes[cholin_genes %in% rownames(Padj_res_NDPDvsNDC)]
length(inter_cholin_NDPD) #3
inter_cholin_NDPD #"GPCPD1" "SRSF12" "CLOCK" 
inter_cholin_PDD <- cholin_genes[cholin_genes %in% rownames(Padj_res_PDDvsNDC)]
length(inter_cholin_PDD) #6
inter_cholin_PDD #"GPCPD1" "SRSF12" "SRSF8"  "BMP2K"  "CLOCK"  "NR1D1" 

shared_cholin <- cholin_genes[cholin_genes %in% rownames(Comb)]
length(shared_cholin) #3
shared_cholin #"GPCPD1" "SRSF12" "CLOCK"

cholin_Diff_NDPD <- cholin_genes[cholin_genes %in% rownames(Diff_NDPD)]
length(cholin_Diff_NDPD) #0

cholin_Diff_PDD <- cholin_genes[cholin_genes %in% rownames(Diff_PDD)]
length(cholin_Diff_PDD) #3
cholin_Diff_PDD # SRSF8 BMP2K NR1D1
###

#create and extract 
counCholin <- countsnorm[c("GPCPD1","CLOCK","SRSF12","SRSF8","BMP2K","NR1D1", "ACHE", "BCHE"), ]
write.csv(counCholin, "C:/Users/Shani Vaknine/Documents/R/mRNA/corrected_DE/counCholin.csv")

resCholin_NDPDvsNDC <- res_NDPDvsNDC[c("GPCPD1","CLOCK","SRSF12","SRSF8","BMP2K","NR1D1", "ACHE", "BCHE"), ]
resCholin_NDPDvsNDC
resCholin_PDDvsNDC <- res_PDDvsNDC[c("GPCPD1","CLOCK","SRSF12","SRSF8","BMP2K","NR1D1", "ACHE", "BCHE"), ]
resCholin_PDDvsNDC

####
#heatmaps
library("genefilter")
library("RColorBrewer")
library("gplots")
topVarGenes <- head(order(rowVars(assay(vsd)), decreasing=TRUE), 35)
heatmap.2( assay(vsd)[ topVarGenes, ], scale="row",
           trace="none", dendrogram="column",
           col = colorRampPalette( rev(brewer.pal(9, "RdBu")) )(255))


sampleDists <- dist(t(assay(vsd)))
sampleDists
sampleDistMatrix <- as.matrix(sampleDists)
rownames(sampleDistMatrix) <- paste(vsd$Diagnosis, colData$sample.name, sep="-")
colnames(sampleDistMatrix) <- NULL
colours = colorRampPalette( rev(brewer.pal(9, "Blues")))(255)
heatmap.2(sampleDistMatrix, trace="none", col=colours)

ntd <- normTransform(ddsHTSeq)
library("pheatmap")
select <- order(rowMeans(counts(ddsHTSeq,normalized=TRUE)),
                decreasing=TRUE)[1:20]
df <- as.data.frame(colData(ddsHTSeq)[,c("Diagnosis","BraakLB")])
pheatmap(assay(ntd)[select,], cluster_rows=FALSE, show_rownames=FALSE,
         cluster_cols=FALSE, annotation_col=df)

