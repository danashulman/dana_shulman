# tRNA fragment file pre-processing for DeSeq2 analysis
# Alignment using MINTmap v1, preprocessing of .fastq files with cutadapt and sickle for quality
# Gilli Moshitzky - Based on Bettina Nadorp's script
# 28.02.2019



# First we want to merge the summary files

# Exclusive Alignment summary
setwd("/Volumes/Gilli_I/Gilli_H9_small_RNA_time_course/TRFs/Alignment/")
library("data.table")
file_list <- list.files(pattern = "exclusive-tRFs.countsmeta.txt")
# Read the files in, assuming comma separator
txt_files_df <- lapply(file_list, function(x) {read.table(file = x, header = T, sep ="\t")})
# Combine them
combined_df <- do.call("rbind", lapply(txt_files_df, as.data.frame)) 
rownames(combined_df) <- file_list
ExclusiveSummary <- combined_df

write.csv(ExclusiveSummary, "ExclusiveSummaryFile.csv")

# Ambiguous Alignment Summary
file_list <- list.files(pattern = "ambiguous-tRFs.countsmeta.txt")
# Read the files in, assuming comma separator
txt_files_df <- lapply(file_list, function(x) {read.table(file = x, header = T, sep ="\t")})
# Combine them
combined_df <- do.call("rbind", lapply(txt_files_df, as.data.frame)) 
rownames(combined_df) <- file_list
AmbiguousSummary <- combined_df

write.csv(AmbiguousSummary, "AmbiguousSummaryFile.csv")


# output files from MINTmap are .txt files with tons of information
# we want to only extract the information on the raw reads to process the files using DeSeq2
# use freads for reading multiple files
# use a for loop for grapping the files and putting them together

file_list <- list.files(pattern = "exclusive-tRFs.expression.txt")
txt_files_df <- lapply(file_list, function(x) {fread(file = x, select = c(1,4), data.table = FALSE)})
combined_df <-Reduce(function(x,y) {merge(x,y, by = "MINTbase Unique ID", all = TRUE)}, txt_files_df)
View(combined_df)
rownames(combined_df) <- combined_df$`MINTbase Unique ID`
combined_df1 <- combined_df[,-1]
colnames(combined_df1) <- gsub("-MINTmap_v1-exclusive-tRFs.expression.txt", "", file_list)
combined_df1[is.na(combined_df1)] <- 0
write.csv(combined_df1, "tRNA_Exclusive_Combined_data.csv")

# merge ambiguous reads
file_list <- list.files(pattern = "ambiguous-tRFs.expression.txt")
txt_files_df <- lapply(file_list, function(x) {fread(file = x, select = c(1,4), data.table = FALSE)})
combined_df <-Reduce(function(x,y) {merge(x,y, by = "MINTbase Unique ID", all = TRUE)}, txt_files_df)
View(combined_df)
rownames(combined_df) <- combined_df$`MINTbase Unique ID`
combined_df1 <- combined_df[,-1]
colnames(combined_df1) <- gsub("-MINTmap_v1-ambiguous-tRFs.expression.txt", "", file_list)
combined_df1[is.na(combined_df1)] <- 0
write.csv(combined_df1, "tRNA_ambiguous_Combined_data.csv")



