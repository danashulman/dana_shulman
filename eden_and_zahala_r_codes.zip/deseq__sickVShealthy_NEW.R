setwd("D:\EdenZahala")
library(dplyr)
library(tidyr)

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("RColorBrewer")
BiocManager::install("DESeq2")                     
library("data.table")
library("DESeq2")
library("ggplot2")
library("limma")


countdata <- read.table("miR_combined_data.csv", sep = ",", header=TRUE, row.names = 2)
countdata <- countdata[,-1]   # without the pre-mature miRs
#countdata[1:5,1:5]

#     !!!! *********** always sort coldata by BUID ********* !!!!


coldata <- read.table("merged_sex_condition_apoe_noNArin.csv", header= TRUE, sep = ",")

#coldata <- coldata[(coldata$brain_region!="NucAcc"),]  # HYPO
#coldata <- coldata[(coldata$brain_region!="Hypothalamus"), ]  # NUCC

coldata <- coldata[(coldata$RIN >= 6),]
coldata <- coldata[(coldata$cogdx == 1 | coldata$cogdx > 3),]
coldata <- coldata[(coldata$condition!="six"), ]
#coldata <- coldata[(coldata$condition!="healthy"), ]

coldata <- coldata[,-c(1, 2, 4, 6 , 21)]  # drop brain_region = 16...
#coldata <- coldata[, -5]
#coldata <- coldata[,-c(3,10,11, 21, 22)]  # for HYPO only: drop race and sex


#title = "Deseq sick- 2-3 vs. healthy- 1 , 6+RIN, Nucc"

title = "Deseq sick(4,5) vs. healthy(1) , 6+RIN"

coldata$BUID <- sapply(coldata$BUID, function(x) paste0("X",x))
coldata$miRNA_batch <- sapply(coldata$miRNA_batch, function(x) paste0("F",x))
#coldata$mRNA_batch <- sapply(coldata$mRNA_batch, function(x) paste0("M",x))
#coldata$RIN <- sapply(coldata$RIN, function(x) paste0("M",x))
#coldata$cogdx <- sapply(coldata$cogdx, function(x) paste0("M",x))

#countdata[1,] <- sapply(countdata[1,], function(x) paste0("X",x))



######################### taking the matching samples #############

n <- colnames(countdata)
idxs <- c()
for (i in 1:ncol(countdata)){
  if (n[i] %in% coldata$BUID)
  {
    idxs <- c(idxs,i)
  }
}

countdata <- countdata[, idxs]
countdata <- as.matrix(countdata)
##################################################################

#write.csv(as.data.frame(countdata), "mirs_mature_SEX_sick_health.csv")


coldata$msex <- as.factor(coldata$msex)
coldata$condition <- as.factor(coldata$condition)
coldata$miRNA_batch <- as.factor(coldata$miRNA_batch)
coldata$RIN_batch<- as.factor(coldata$RIN_batch)
coldata$brain_region<- as.factor(coldata$brain_region)

#coldata$RIN<- as.factor(coldata$RIN)
#coldata$cogdx <- as.factor(coldata$cogdx)


dds <- DESeqDataSetFromMatrix(countData=countdata, colData=coldata, design=~RIN_batch 
                                + miRNA_batch +msex  + brain_region+ condition) #  + condition
dds

mean(rowMeans(counts(dds))) #1442.671
keep <- rowMeans(counts(dds)) >= 100
dds <- dds[keep,]

dds$condition <- factor(dds$condition, levels = c("healthy","sick"))
#dds$msex <- factor(dds$msex, levels = c("male","female"))
#dds$condition <- relevel(dds$condition, ref = "sick")
#dds$msex <- relevel(dds$msex, ref = "male")
dds <- DESeq(dds)

resultsNames(dds)
plotDispEsts(dds, main = title)

#countsnorm = counts(dds, normalize=T)
#write.csv(as.data.frame(countsnorm), "countsnorm.csv")


#res <- results(dds, alpha=0.05) #setting alpha to be 0.05
res <- results(dds)
res <- results(dds, contrast=c("condition", "sick", "healthy"))
#res <- results(dds, contrast=c("msex","male", "female"))
summary(res) #summarize results

resOrdered <- res[order(res$padj),] # order results table by the smallest p value
resOrdered
resOrdered[1:10, ] #present 10 most significant genes
sum(res$padj < 0.05, na.rm=TRUE) #How many genes were less than 0.05 (41)
table(is.na(res$padj))  #0 NA
results_healthy_sick<-resOrdered
write.csv(results_healthy_sick,"results_healthy_sex.csv")
#nsub=nrow(dds)
#vsd <- vst(dds, blind=FALSE)

rld <-rlogTransformation(dds)

mat <- assay(rld)
mat <- limma::removeBatchEffect(mat, rld$RIN_batch)
mat <- limma::removeBatchEffect(mat, rld$miRNA_batch)
assay(rld) <- mat 

#sampleDists <- dist(t(assay(vsd)))
sampleDists <- dist(t(assay(rld)))

library("RColorBrewer")
library("pheatmap")
sampleDistMatrix <- as.matrix(sampleDists)
#rownames(sampleDistMatrix) <- paste(vsd$Diagnosis)
rownames(sampleDistMatrix) <- paste(rld$Diagnosis)

colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
#pheatmap(sampleDistMatrix, clustering_distance_rows=sampleDists,clustering_distance_cols=sampleDists,
#         col=colors)

plotPCA(rld, intgroup="msex")
plotPCA(rld, intgroup="condition")
plotPCA(rld, intgroup="APOE")
plotPCA(rld, intgroup="RIN_batch")
plotPCA(rld, intgroup="miRNA_batch")
plotPCA(rld, intgroup="cts_mmse30_lv")
#plotPCA(rld, intgroup=c("msex","condition"))




mir5 <- "hsa-miR-132-5p"
mir6 <-"hsa-miR-129-2-3p"
mir7<-"hsa-miR-455-5p"

mir1 <- "hsa-miR-132-3p"
mir2 <-"hsa-miR-455-3p"
mir3 <- "hsa-miR-129-1-3p"
mir4 <- "hsa-miR-129-5p"
 
plotCounts(dds, gene=mir1, intgroup="condition")
plotCounts(dds, gene=mir2, intgroup="condition")
plotCounts(dds, gene=mir3, intgroup="condition")
plotCounts(dds, gene=mir4, intgroup="condition")
plotCounts(dds, gene=mir5, intgroup="condition")
plotCounts(dds, gene=mir6, intgroup="condition")
plotCounts(dds, gene=mir7, intgroup="condition")

#boxplot(rpkm ~ dds$condition, countsnorm[mir1,], xlab=mir1, ylab="counts")


BiocManager::install("calibrate")
library("calibrate")

library(RColorBrewer)
(mycols <- brewer.pal(8, "Dark2"))
rld_pca <- function (rld, intgroup = "condition", ntop = 500, colors=NULL, legendpos="bottomleft", main="PCA Biplot", textcx=1, ...) {
  require(genefilter)
  require(calibrate)
  require(RColorBrewer)
  rv = rowVars(assay(rld))
  select = order(rv, decreasing = TRUE)[seq_len(min(ntop, length(rv)))]
  pca = prcomp(t(assay(rld)[select, ]))
  fac = factor(apply(as.data.frame(colData(rld)[, intgroup, drop = FALSE]), 1, paste, collapse = " : "))
  if (is.null(colors)) {
    if (nlevels(fac) >= 3) {
      colors = brewer.pal(nlevels(fac), "Paired")
    }   else {
      colors = c("black", "red")
    }
  }
  pc1var <- round(summary(pca)$importance[2,1]*100, digits=1)
  pc2var <- round(summary(pca)$importance[2,2]*100, digits=1)
  pc1lab <- paste0("PC1 (",as.character(pc1var),"%)")
  pc2lab <- paste0("PC1 (",as.character(pc2var),"%)")
  plot(PC2~PC1, data=as.data.frame(pca$x), bg=colors[fac], pch=21, xlab=pc1lab, ylab=pc2lab, main=main, ...)
  with(as.data.frame(pca$x), textxy(PC1, PC2, labs=rownames(as.data.frame(pca$x)), cex=textcx))
  legend(legendpos, legend=levels(fac), col=colors, pch=20)
  #     rldyplot(PC2 ~ PC1, groups = fac, data = as.data.frame(pca$rld),
  #            pch = 16, cerld = 2, aspect = "iso", col = colours, main = draw.key(key = list(rect = list(col = colours),
  #                                                                                         terldt = list(levels(fac)), rep = FALSE)))
}
png("qc-pca.png", 1000, 1000, pointsize=20)
rld_pca(rld, colors=mycols, intgroup="condition", xlim=c(-75, 50))
dev.off()

